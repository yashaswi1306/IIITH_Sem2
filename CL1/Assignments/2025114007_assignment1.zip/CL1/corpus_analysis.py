# TASK 4 PART 2

from collections import Counter
import math

import matplotlib.pyplot as plt
import numpy as np

def compute_word_frequencies(tokens):
    '''Counts each token'''
    return Counter(tokens)

def compute_rank_frequency(freq_dict):
    '''Append into frequency list + sort'''
    sorted_items = sorted(freq_dict.items(),key=lambda x: x[1],reverse=True)
    rank_freq = []
    for rank, (word, freq) in enumerate(sorted_items, start=1):
        rank_freq.append((rank, freq))
    return rank_freq

def log_transform(rank_freq):
    '''Take log of values'''
    log_rank=[]
    log_freq=[]
    for rank, freq in rank_freq:
        if rank>0 and freq>0:
            log_rank.append(math.log(rank))
            log_freq.append(math.log(freq))
    return log_rank,log_freq
    
import re

common={"Rifle","Good","good","Pressing","pressing","It's","We","Otherwise","rifle","we","Tonight","Our","Where","tonight","our","where","otherwise","Such","File","Relax","This","That","Those","These","It","He","She","They","The","This","When","If","As","But","And","Or","That","These","Those","While","Although","Because","We","I","His","Her","Their","Its","In","On","At","By","For","With"
}

jobs={"Mr.":"__MR__","Mrs.":"__MRS__","Ms.":"__MS__","Dr.":"__DR__","Engg.":"__ENGG__"}

def keepjobs(text):
    for k,v in jobs.items():
        text=re.sub(rf"\b{k}",v,text)
    return text

def getjobs(text):
    for k,v in jobs.items():
        text=text.replace(v.lower(),k)
        text=text.replace(v,k)
    return text

def pnoun(text):
    pn=set()
    for i in sentencetokenization(text):
        word=re.findall(r"\b[A-Z][a-z]+\b",i)
        for a in word[1:]:
            if a not in common:
                pn.add(a)
    return pn

def restorepn(text,pns):
    for p in pns:
        text=re.sub(rf"\b{p.lower()}\b",p,text)
    return text
    
def normalizewhitespace(text):
    line=text.splitlines()
    line=[re.sub(r"\s+", " ", l).strip() for l in line]
    return "\n".join(line)

def cleanup(text):
    text=re.sub(r"--+","",text)
    text=re.sub(r"; ;",";",text)
    text=re.sub(r"!!+","",text)
    text=re.sub(r"\?\?","?",text)
    text=re.sub(r":",",",text)
    return text

def normalizecase(text):
    '''Returns text in lowercase'''
    # parts=re.split(r"([.!?])\s*",text)
    # for i in range(0,len(parts),2):
    #     if (parts[i]):
    #         parts[i]=parts[i][0].lower()+parts[i][1:]
    # return ''.join(parts)
    return text.lower()


def normalizecontractions(text):
    '''Expand English Contractions
    (who'd can be who would or who had)
    Possesives handeled'''
    
    exceptions={"smith's": "SMPH", "thor's": "TPH","white's": "WPH","pool's": "PPH","slope's": "SPH","director's": "DPH","morning's": "MPH","men's": "mePH","children's": "chPH","Mr":"MRPH","Mrs":"MRSPH","Ms":"MSPH","Dr":"DRPH","Engg":"ENGGPH"
    }

    for k,v in exceptions.items():
        text=text.replace(k,v)

    text=re.sub(r"(?<!\w)'em\b","them",text)
    text=re.sub(r"\bcan't\b","cannot",text)
    text=re.sub(r"\bThat's\b","that is",text)
    text=re.sub(r"\bwon't\b","will not",text)
    text=re.sub(r"\bshan't\b","shall not",text)
    text=re.sub(r"\b'em\b","them",text)
    text=re.sub(r"\bain't\b","is not",text)
    text=re.sub(r"\bit's\b","it is",text)
    text=re.sub(r"\bwhat's\b","what is",text)
    text=re.sub(r"\bthere's\b","there is",text)
    text=re.sub(r"\bthat's\b","that is",text)
    text=re.sub(r"\bhe's\b","he is",text)
    text=re.sub(r"\bshe's\b","she is",text)
    text=re.sub(r"\bwho's\b","who is",text)
    # text=re.sub(r"\b(\w+)'s'\b",r"\1 is",text)
    text=re.sub(r"\b(\w+)n't\b",r"\1 not",text)
    text=re.sub(r"\b(\w+)'ve\b",r"\1 have",text)
    text=re.sub(r"\b(\w+)'d\b",r"\1 had",text)
    text=re.sub(r"\b(\w+)'m\b",r"\1 am",text)
    text=re.sub(r"\b(\w+)'re\b",r"\1 are",text)
    text=re.sub(r"\b(\w+)'ll\b",r"\1 will",text)

    for k,v in exceptions.items():
        text=text.replace(v,k)

    return text

def sentencetokenization(text):

    parts=re.split(r"([.!?])",text)
    sentences=[]
    for i in range(0,len(parts)-1,2):
        sentences.append(parts[i].strip()+parts[i+1])
    if len(parts)%2 and parts[-1].strip():
        sentences.append(parts[-1].strip())

    return sentences

def normalizequotes(text):
    text=text.replace("``",'"').replace("''",'"')
    text=text.replace("‘","'").replace("’","'")
    text=text.replace("“",'"').replace("”",'"')
    return text

def wordtokenization(sentence):
    return re.findall(r"(?:Mr|Mrs|Ms|Dr|Engg)\.|"r"[A-Za-z]+'s|"r"[A-Za-z]+-[A-Za-z]+|"r"[A-Za-z]+|"r"[.!?,]",sentence,flags=re.IGNORECASE)

def keepposs(text):
    return re.sub(r"\b([A-Z][a-z]+)(['’]s)\b",r"\1<POS>\2",text)

def caps(match):
    return match.group(1).capitalize()+match.group(2)

def getposs(text):
    return re.sub(r"\b([a-z]+)<pos>(['’]s)\b",caps,text)


def normalizetext(text):
    text=normalizewhitespace(text)
    text=normalizequotes(text)
    text=keepjobs(text)    
    text=keepposs(text)
    text=normalizecase(text)
    text=cleanup(text)
    text=normalizecontractions(text)
    text=getposs(text)
    text=getjobs(text)    
    return text



f=open("corpus.txt", "r", encoding="utf-8")
text=f.read()

pn=pnoun(text)
normalized=normalizetext(text)
normalized=restorepn(normalized, pn)
# normalized=keepsome(normalized)

sentences=sentencetokenization(normalized)
# sentences=[getback(s) for s in sentences]
tokens=[]

for sentence in sentences:
    t=wordtokenization(sentence)
    if t:
        tokens.append(t)

ftokens=[token for sentence in tokens for token in sentence]
print(ftokens[:20])

f= open("normalizedtext.txt", "w", encoding="utf-8")
f.write(normalized)

frequency=compute_word_frequencies(ftokens)
rankfreq = compute_rank_frequency(frequency)

print(frequency)
print(rankfreq)

log_rank,log_freq=log_transform(rankfreq)

plt.figure(figsize=(8, 6))
plt.scatter(log_rank,log_freq,s=8)
plt.xlabel("log(rank)")
plt.ylabel("log(frequency)")
plt.title("Zipf's Law Plot")
plt.grid(True)
plt.show()

slope, intercept = np.polyfit(log_rank,log_freq,1)

plt.figure(figsize=(8, 6))
plt.scatter(log_rank,log_freq,s=8,label="Data")
plt.plot(log_rank,[slope*x + intercept for x in log_rank],color="red",label=f"slope = {slope:.2f}")
plt.xlabel("log(rank)")
plt.ylabel("log(frequency)")
plt.title("Zipf's Law with Slope")
plt.legend()
plt.grid(True)
plt.show()


