import sys
import json

def map_relation ( paninian_tag ):
    """
    Maps a single Paninian dependency tag to a UD tag. 
    Returns 'dep' as a fallback for unknown/unmapped tags.
    """
    # TODO: Define your mapping logic here
    mapping_dict = {
        'k1': 'nsubj',
        'k1s':'nsubj',       
        'k1u':'nsubj',      
        'k3':'obl',         
        'k7':'obl',
        'k5':'obl',
        'k5prk':'obl',       
        'k1o': 'nsubj',
        'k2o': 'obj',
        'k3o': 'obl',
        'k4o': 'iobj',
        'k5o': 'obl',
        'k6o': 'nmod:poss',
        'k7o': 'obl',
        'k7po':'obl',
        'k7to':'obl',
        'k4':'iobj',         
        'k4s': 'iobj',        
        'k4a': 'obl',    
        'k7p': 'obl',         
        'k7t': 'obl',         
        'k6':'nmod:poss',
        'k6s': 'nmod:poss',    
        'k6t': 'nmod',     
        'k2':'obj',
        'xcomp':'xcomp',
        'cop': 'cop',
        'aux': 'aux',
        'aux__pass': 'aux:pass',
        'det': 'det',
        'dem': 'det',  
        'lwg__neg':'advmod',
        'lwg__vaux': 'aux',
        'lwg__rp':'discourse',
        'lwg__intf': 'advmod',
        'lwg__cont': 'advcl',
        'lwg__quit': 'discourse',
        'k2s': 'obj',        
        'k2u': 'obj',         
        'k2g': 'obj',  
        'k1_pass':'nsubj:pass',
        'jjmod':'amod',
        'jjmod_vy':'amod',        
        'rbmod':'advmod',
        'adv': 'advmod',
        'adv_freq':'advmod',       
        'adv_indef': 'advmod',       
        'sent_adv':'advmod',
        'vmod':'acl',
        'vmod_relc': 'acl:relcl',
        'pk1': 'nsubj:caus',   
        'pk2': 'obj',          
        'rh':'advcl',
        'rt':'advcl',
        'ras_loc':'obl',
        'rask':'obl',
        'rd':'obl',
        'rsp': 'obl',
        'rvks':'advcl',
        'rvk': 'advcl',
        'rbks':'obl',
        'nmod':'nmod',
        'ccof':'conj',
        'ymod':'cc',
        'pof__cn':'compound:lvc',
        'pof__redup':'compound:redup',
        'cmn': 'compound',
        'lwg__psp':'case',
        'k2_pass':'nsubj:pass',
        'appos':'appos',
        'csubj':'csubj',
        'ccomp':'ccomp',
        'main':'root',         
        'root':'root',
        'punc':'punct',
        'punct':'punct',
        'discourse': 'discourse', 
        'dep': 'dep',          
        'null':'dep',  
    }
    return mapping_dict .get(paninian_tag , 'dep')

def process_file (input_path , output_path ):
    """
    Reads the input JSON , applies the mapping , and writes to output JSON.
    """
    with open(input_path , 'r', encoding='utf-8') as f:
        tree_data = json.load(f) 
    for node in tree_data :
            p_tag = node.get('paninian_relation', '')
            node['ud_relation'] = map_relation (p_tag)
    with open(output_path , 'w', encoding='utf-8') as f:
        json.dump(tree_data , f, indent =4)

if __name__ == "__main__":
    # Do NOT modify this execution block
    if len(sys.argv) != 3:
        print("Usage: python converter.py <input.json > <output.json >")
        sys.exit (1)
    input_file = sys.argv [1]
    output_file = sys.argv [2]
    process_file (input_file , output_file )
