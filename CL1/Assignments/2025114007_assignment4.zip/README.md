Yashaswi Priya - 2025114007
Assignment4_Answers.pdf has order of:
10 Universal Dependencies
10 X bar 
10 Paninian Dependencies

*** PUNC occuring at the end of the sentence HAS NOT BEEN CONSIDERED in the mapping. In any case, it is always simply attached to the root as 'punc' tag.

For Paninian trees, k1,..k7 along with aux,mod etc. tags have been used instead of the usual sanskrit tags.