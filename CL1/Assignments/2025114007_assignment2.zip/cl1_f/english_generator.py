import re
def generate_english(root,features ):
    """
    Rule -based morphological generator for English
    """
    unchanged=["fish","salmon","trout","moose","sheep","deer","aircraft","species","swine","buffalo","reindeer","elk","shellfish","hovercraft","fruit","furniture","offspring","advice","gas","analysis"]
    exceptions={"wives":"wife","calves":"calf","selves":"self","ourselves":"ourself","geese":"goose","elves":"elf","knives":"knife","wolves":"wolf","lives":"life","leaves":"leaf","teeth":"tooth","mice":"mouse","feet":"foot","oxen":"ox","children":"child","brethren":"brother","cacti":"cactus","nuclei":"nucleus","fungi":"fungus","data":"datum","syllabi":"syllabus","alumni":"alumnus","criteria":"criterion","phenomena":"phenomenon","media":"medium","bacteria":"bacterium","cattle":"cow","halves":"half","heroes":"hero","shoes":"shoe","thieves":"thief","loaves":"loaf","shelves":"shelf","graves":"grave"}
    pronouns={"they":"he/she","we":"I"}
    except_sg={val:key for key,val in exceptions.items()}
    pro_sg={val:key for key,val in pronouns.items()}
    root=root.lower()
    if "N" in features:
        if "PL" in features:
            if root in unchanged:
                return root
            elif root in except_sg:
                return except_sg[root]
            elif root in pro_sg:
                return pro_sg[root]
            elif re.search(r"[^aeiou]y$",root):
                return re.sub(r"y$","ies",root)
            elif re.search(r"(s|x|z|ch|sh)$",root):
                return root+"es"
            elif re.search(r"man$",root):
                return re.sub(r"man$","men",root)
            else:
                return root +"s"
        elif "SG" in features:
            if root in unchanged:
                return root
            elif root in exceptions:
                return exceptions[root]
            elif root in pronouns:
                return pronouns[root]
            elif re.search(r"ies$",root):
                return re.sub(r"ies$","y",root)
            elif re.search(r"(xes|ches|shes|ses|zes)$",root):
                return re.sub(r"es$", "", root)
            elif re.search(r"ves$",root):
                root=re.sub(r"ves$","f",root)
                return root
            elif re.search(r"men$",root):
                root=re.sub(r"men$","man",root)
                return root
            elif re.search(r"s$",root) and not re.search(r"ss$",root):
                return re.sub(r"s$","",root)
            else:
                return root

    else:
        return root

print(generate_english('railway-man', ['N', 'PL']))
print(generate_english('stone', ['N', 'PL']))
print(generate_english('trespasser', ['N', 'PL']))
print(generate_english('calf', ['N', 'PL']))
print(generate_english('leaf', ['N', 'PL']))
print(generate_english('milk', ['N', 'SG']))
print(generate_english('water', ['N', 'SG']))
print(generate_english('half', ['N', 'SG']))
print(generate_english('catch', ['N', 'PL']))
print(generate_english('chess', ['N', 'PL']))
print(generate_english('movie', ['N', 'PL']))
print(generate_english('datum', ['N', 'PL']))
print(generate_english('alumnus', ['N', 'PL']))
print(generate_english('news', ['N', 'SG']))
print(generate_english('speciman', ['N', 'PL']))