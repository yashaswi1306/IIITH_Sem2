import re
def generate_indian(root, features):
    """
    Morphological generator for an Indian language
    """
    unchanged=["pitā", "dātā", "mātā", "bhrātā", "netā", "vidhātā", "bhikṣā", "kṛpā", "dayā", "māyā", "ādamī", "pānī", "sipāhī", "vidyārthī", "m~trī", "sāthī", "adhikārī","ḍākū", "bābū", "shatru", "laḍḍū", "ā~sū", "jādū", "ālū", "sādhu"]
    word=root
    exceptions={"ḍibiyā":"ḍibbā","thaliyā":"thailī","chiḍa़iyā~":"chiḍa़iyā'","buḍha़iyā~":" buḍha़iyā","khaṭiyā~": "khaṭiyā","chuhiyā~":"chuhiyā","guḍa़iyā":"guḍa़iyā","kalam":"kalame~","rāt":"rāte~","āṅkh":"āṅkhe~","kitāb":"kitābe~","mez":"meze~","guru":"gurugaṇa"}
    except_sg={val:key for key,val in exceptions.items()}
    root=root.lower()
    if "N" in features:
        if "PL" in features:
            if root in unchanged:
                return root
            elif root in except_sg:
                return except_sg[root]
            elif re.search(r"(gaṇa|varga|vṛmda)$", word):
                root = re.sub(r"(gaṇa|varga|vṛmda)$", "", word)#left
                return root
            elif re.search(r"ī$", word):
                root = re.sub(r"ī$","iyā~", word)
                return root
            elif re.search(r"ā$", word):
                root = re.sub(r"ā$", "e", word)
                return root
            elif re.search(r"u$", word):
                root = re.sub(r"u$", "ue~", word)
                return root
            elif re.search(r"au$", word):
                root = re.sub(r"au$", "aue~", word)
                return root
            else:
                return root #for words like doodh, pyaar etc.
        elif "SG" in features:
            if root in unchanged:
                return root
            elif root in exceptions:
                return exceptions[root]
            elif re.search(r"(gaṇa|varga|vṛmda)$", word):
                root = re.sub(r"(gaṇa|varga|vṛmda)$", "", word)
                return root
            elif re.search(r"(o|yo)$", word):
                root = re.sub(r"(o|yo)$", "", word)
                return root
            elif re.search(r"iyā~$", word):
                root = re.sub(r"iyā~$", "ī", word)
                return root
            elif re.search(r"(e~|en)$", word):
                root = re.sub(r"(e~|en)$", "", word)
                return root
            elif re.search(r"e$", word):
                root = re.sub(r"e$", "ā", word)
                return root
            elif re.search(r"(āe~|āen)$", word):
                root = re.sub(r"(āe~|āen)$", "ā", word)
                return root
            elif re.search(r"(ue~|uen)$", word):
                root = re.sub(r"(ue~|uen)$", "u", word)
                return root
            elif re.search(r"(aue~|auen)$", word):
                root = re.sub(r"(aue~|auen)$", "au", word)
                return root
            else:
                return root
            
        
    
print(generate_indian("devagaṇa",["N","SG"]))
print(generate_indian("chhātravarga",["N","PL"]))
print(generate_indian("laḍa़kiyā~",["N","SG"]))
print(generate_indian("laḍa़kā",["N","PL"]))
print(generate_indian("kitāben",["N","SG"]))
print(generate_indian("mālāe~",["N","PL"]))
print(generate_indian("bahue~",["N","SG"]))
print(generate_indian("aurat",["N","PL"]))#
print(generate_indian("rāte~",["N","SG"]))
print(generate_indian("kakṣā",["N","PL"]))
print(generate_indian("chiḍa़iyā~",["N","SG"]))
print(generate_indian("laḍa़kā",["N","PL"]))
print(generate_indian("vyavasthā",["N","SG"]))
print(generate_indian("laḍa़kon",["N","SG"]))
print(generate_indian("chiḍa़iyā~",["N","PL"]))