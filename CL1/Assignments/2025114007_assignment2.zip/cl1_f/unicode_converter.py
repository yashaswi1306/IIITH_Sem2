def unicode_converter(text):
    """
    Converts devanagiri script into ISO representation
    """
    vowels={"अ":"a","आ":"ā","इ":"i","ई":"ī","उ":"u","ऊ":"ū","ऋ":"ri","ए":"e","ऐ":"ai","ओ":"o","औ":"au"}
    consonants={"क":"k","ख":"kh","ग":"g","घ":"gh","ङ":"ṅ","च":"ch","छ":"chh","ज":"j","झ":"jh","ञ":"ñ","ट":"ṭ","ठ":"ṭh","ड":"ḍ","ढ":"ḍh","ण":"ṇ","त":"t","थ":"th","द":"d","ढ़": "ḍrh","ड़":"ḍr","ध":"dh","न":"n","प":"p","फ":"ph", "ब":"b","भ":"bh","म":"m","य":"y","र":"r","ल":"l","व":"v","श":"sh","ष":"ṣ","स":"s","ह":"h"}
    maatra={"ा":"ā","ि":"i","ी":"ī","ु":"u","ू":"ū","ृ":"ṛ","े":"e","ै":"ai","ो":"o","ौ":"au","ं":"n","ः":"h","ँ":"~"}
    nukta={"क़":"q","ख़":"x","ज़":"z","फ़":"f"}
    halant="्"
    output=""
    mat_hal=False #Taaki do baar naa ho halant yaa phir maatra
    for i,char in enumerate(text):
        if mat_hal:
            mat_hal=False#ek baar process hua, toh next time false krke chod do
            continue
        if(char=="र"and(i+1)<len(text)and text[i+1]==halant):
            output+="r"
            mat_hal=True
            continue
        if char in vowels:
            output+=vowels[char]
            continue
        if char in nukta:
            act=nukta[char]
        elif char in consonants:
            act=consonants[char]
        else:
            act=None
        
        if act:
            if (i+1<len(text)):
                next=text[i+1]
            else:
                next = None
            if next in maatra:
                output+=act+maatra[next]
                mat_hal=True
            elif next==halant:
                output+=act
                mat_hal=True
            else:
                output+=act+"a"
            continue

        if char in maatra:
            output+=maatra[char]
            continue

        output+=char

    return output
        
print(unicode_converter("देवगण\nछात्रवर्ग\nलड़कियाँ\nकिताबें\nलड़के\nमालाएँ\nबहुएँ\nनौएँ\nचिड़ियाँ\nलड़कों\nरातें\nबातें\nकक्षाएँ\nव्यवस्थाएँ\nऔरतें"))