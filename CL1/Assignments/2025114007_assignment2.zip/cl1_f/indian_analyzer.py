import re
def analyze_indian(word):
    """
    Morphological analyzer using converted representation
    """
    exceptions={"ḍibiyā":"ḍibbā","thaliyā":"thailī","chiḍa़iyā~":"chiḍa़iyā'","buḍha़iyā~":" buḍha़iyā","khaṭiyā~": "khaṭiyā","chuhiyā~":"chuhiyā","guḍa़iyā":"guḍa़iyā"}
    if word in exceptions:
        return exceptions[word], ["N","PL"]
    if re.search(r"(gaṇa|varga|vṛmda)$", word):
        root = re.sub(r"(gaṇa|varga|vṛmda)$", "", word)
        return root, ["N", "PL"]
    elif re.search(r"iyā~$", word):
        root = re.sub(r"iyā~$", "ī", word)
        return root, ["N", "PL"]
    elif re.search(r"(e~|en)$", word):
        root = re.sub(r"(e~|en)$", "", word)
        return root, ["N", "PL"]
    elif re.search(r"e$", word):
        root = re.sub(r"e$", "ā", word)
        return root, ["N", "PL"]
    elif re.search(r"(āe~|āen)$", word):
        root = re.sub(r"(āe~|āen)$", "ā", word)
        return root, ["N", "PL"]
    elif re.search(r"(ue~|uen)$", word):
        root = re.sub(r"(ue~|uen)$", "u", word)
        return root, ["N", "PL"]
    elif re.search(r"(aue~|auen)$", word):
        root = re.sub(r"(aue~|auen)$", "au", word)
        return root, ["N", "PL"]
    else:
        return word, ["N","SG"]
    
print(analyze_indian("devagaṇa"))
print(analyze_indian("chhātravarga"))
print(analyze_indian("laḍa़kiyā~"))
print(analyze_indian("laḍa़kā"))
print(analyze_indian("kitāben"))
print(analyze_indian("mālāe~"))
print(analyze_indian("bahue~"))
print(analyze_indian("aurate~"))#
print(analyze_indian("rāte~"))
print(analyze_indian("kakṣā"))
print(analyze_indian("chiḍa़iyā~"))
print(analyze_indian("bāten"))
print(analyze_indian("vyavasthā"))
print(analyze_indian("laḍa़kon"))
print(analyze_indian("chiḍa़iyā~"))