Assignment-2 

Computational Linguistics-1 

Yashaswi Priya - 2025114007 



Task 1: 

Regex Grouping: 

1. Words ending in ‘men’: Words like firemen, women, railway-men, men etc. are all converted to their singular form by changing the \_men to \_man. 

2. Words ending in ‘ves’: Words like loaves, wolves, calves etc. are all converted to their singular form by changing the \_ves to \_f. However, words like wives -> wife, graves -> grave, lives -> life etc. DO NOT 

follow this pattern. Hence, they have been separately stored in the edge cases dictionary. 

3. Words ending in ‘xes’, ‘ches’, ‘shes’, ‘ses’, ‘zes’: Words like batches, exes, fishes etc. are all converted to their singular form by removing the \_es \(batch, ex, fish respectively\). 

4. Words ending in ‘s’: 

In general, a majority of words that don’t fit in the other categories, are converted to their singular form by simply removing an s. Eg. boys -> boy, girls -> girl etc 5. Words that remain unchanged: Words like fish, deer, sheep etc. remain unchanged upon pluralization. Hence, they have been stored separately. 

6. Edge cases: 

Words that DO NOT follow any set of rules \(oxen -> ox, children -> child, data -> datum\) have been stored separately with their singular counterparts. 





Testing: 



Correct Cases: 

railway-men: \('railway-man', \['N', 'PL'\]\) stones: \('stone', \['N', 'PL'\]\) trespassers: \('trespasser', \['N', 'PL'\]\) calves: \('calf', \['N', 'PL'\]\) half: \('half', \['N', 'SG'\]\) catches: \('catch', \['N', 'PL'\]\) they: \('he/she', \['PN', 'PL'\]\) data: \('datum', \['N', 'PL'\]\) alumni: \('alumnus', \['N', 'PL'\]\) colleges: \('college', \['N', 'PL'\]\) candies: \('candy', \['N', 'PL'\]\) Ambiguous Cases: 

leaves: \('leaf', \['N', 'PL'\]\) However, leaves can be both leaf -> leaves or leave -> leaves, depending upon the context. 

\('milk', \['N', 'SG'\]\) 

\('water', \['N', 'SG'\]\) 

Milk and water are uncountable though, so it’s not necessarily SG, it should be SG/PL or UNC. 



Incorrect Cases: 

movies: \('movy', \['N', 'PL'\]\) specimen: \('speciman', \['N', 'PL'\]\) 

Should be movies -> movie and specimen is SG itself. This shows that it’s almost impossible to account for all such edge cases in the ‘exceptions’ dictionary or the ‘unchanged’ list. 





Task 2: 

Regex Grouping: 

PL to SG \(same as Task1\): 1. Words ending in ‘men’: Words like firemen, women, railway-men, men etc. are all converted to their singular form by changing the \_men to \_man. 

2. Words ending in ‘ves’: Words like loaves, wolves, calves etc. are all converted to their singular form by changing the \_ves to \_f. However, words like wives -> wife, graves -> grave, lives -> life etc. DO NOT 

follow this pattern. Hence, they have been separately stored in the edge cases dictionary. 

3. Words ending in ‘xes’, ‘ches’, ‘shes’, ‘ses’, ‘zes’: Words like batches, exes, fishes etc. are all converted to their singular form by removing the \_es \(batch, ex, fish respectively\). 

4. Words ending in ‘s’: 

In general, a majority of words that don’t fit in the other categories, are converted to their singular form by simply removing an s. Eg. boys -> boy, girls -> girl etc 5. Words that remain unchanged: Words like fish, deer, sheep etc. remain unchanged upon pluralization. Hence, they have been stored separately. 

6. Edge cases: 

Words that DO NOT follow any set of rules \(oxen -> ox, children -> child, data -> datum\) have been stored separately with their singular counterparts. 



SG to PL: 

1. Words ending in ‘man’: Words like fireman, woman, railway-man, man etc. are all converted to their plural form by changing the \_man to \_men. 

2. Words ending in ‘\_Cy’: \(C = consonant\) 

Words ending in\_ Cy change into \_Cies upon pluralization. 

Eg. che 

3. Words ending in ‘s’, ‘x’, ‘z’, ‘ch’, ‘sh’: Words like batch, ex, fish etc. are all converted to their plural form by appending ‘\_es’ 

\(batch\_es, ex\_es, fish\_es respectively\). 





Testing: 



Correct Cases: 



Input 

Change Plurality to 

Output 

'stone' 

'PL' 

stones 

'trespasser' 

'PL' 

trespassers 

'calf' 

'PL' 

calves 

'leaf' 

'PL' 

leaves 

'milk' 

'SG' 

milk 

'water' 

'SG' 

water 

'half' 

'SG' 

half 

'catch' 

'PL' 

catches 

'movie' 

'PL' 

movies 

'datum' 

'PL' 

data 

'alumnus' 

'PL' 

alumni 

'railway-man' 

'PL' 

railway-men 





Incorrect Cases: 



Input 

Change Plurality to 

Output 

'chess' 

'PL' 

chesses 

'news' 

'SG' 

new 

'speciman' 

'PL' 

specimen 



The chess -> chesses , news ->new and speciman -> specimen are all examples of it not being possible to ensure that all the exceptions in a language are stored separately in your corpus. 





Task 3: 

Devanagari : IPA : 

अ : / / 

आ : / ä/ 

इ : /ɪ/ 

ई : /iː/ 

उ : /ʊ/ 

ऊ : /uː/ 

ऋ : /ɾi/ 

ए : /eː/ 

ऐ : /ɛː/ 

ओ : /oː/ 

औ : /ɔː/ 

क : /k/ 

ख : /kʰ/ 

ग : /g/ 

घ : / gʰ/ 

ङ : /ŋ/ 

च : /t͡ʃ/ 

छ : /t͡ʃʰ/ 

ज : /d͡ʒ/ 

झ : /d͡ʒ ʰ/ 

ञ : /ɲ/ 

ट : /ʈ/ 

ठ : /ʈʰ/ 

ड : /ɖ/ 

ढ : /ɖʰ/ 

ण : /ɳ/ 

त : /t̪/ 

थ : /t̪ʰ/ 

द : /d̪/ 

ध : /d̪ʰ/ 

न : /n/ 

प : /p/ 

फ : /pʰ/ 

ब : /b/ 

भ : /b ʰ/ 

म : /m/ 

य : /j/ 

र : /ɾ/ 

ल : /l/ 

व : /ʋ/ 

श : /ʃ/ 

ष : /ʂ/ 

स : /s/ 

ह : /ɦ/ 

क़ : /q/ 

ख़ : /x/ 

ज़ : /z/ 

फ़ : /f/ 

◌ं : /ŋ/ 

◌ँ : /~/ 

◌ः : /h/ 

◌् : / / deletion 



Why this conversion helps morphology: 

In the consonants themselves, no ‘a’ \(/ /\) has been added. However, the if the consonant occurs WITHOUT another maatra or halant, then the ‘a’ is added back to the end. As both the devanagiri and roman alphabets more or less have each character associated with one phone, we can connect it as: 

Devanagari \[x\] -> Phone \[x\] -> Roman \[x\] 



Testing: 



Correct Cases: 

ान 

jñāna 

दुः ख 

duhkha 

लड़का 

laḍa◌़kā 

हँसी 

h~sı̄ 

ि य 

priya 

ज़मीन 

zamı̄na 

अंक 

anka 

े 

kṣetra 

श



shakti 



Incorrect Cases: 

कृ 

kṛṣṇa 

गृह 

gṛha 

भारत 

bhārata 

िवकास vikāsa 

संबंध 

snbndha 

सं ृ त 

snskṛta 





As there exists a schwa sound at the end of ि य and े but not at the end of भारत and सं ृ त, there exists the case if the trailing ‘a’, which is correct in some cases and incorrect in others. Moreover, for words like संबंध -> snbndha \(sambandha\), the one to one mapping of a symbol to a letter doesn’t 

work very well; for eg. here, because the anuswaar can be both ‘m’ or ‘n’ depending on context \(\[m\] 

next to bilabial plosive, \[n\] everywhere else\). 



Task 4: 

Regex Grouping: 

Regex Grouping 

Example 

\(gaṇa|varga|vṛmda\)$ 

देव, छा -> देवगण, छा वग 

\(iyā~\)$ 

लड़की -> लड़िकयाँ 

\(\[e~|en\]\)$ 

िकताब -> िकताब 

\(e\)$ 

लड़का -> लड़के 

\(\[āe~|āen\]\)$ 

माला -> मालाएँ 

\(\[ue~|uen\]\)$ 

ब -> ब एँ 

\(\[aue~|auen\]\)$ 

नौ -> नौएँ 



\(o|yo\)$ OBL case not considered Testing: 



Correct Cases: 

devagaṇa 

deva 

chhātravarga 

chhātra 

laḍa◌़kiyā~ 

laḍa◌़kı̄ 

kitāben 

kitāb 

laḍa◌़ke 

laḍa◌़ka 

mālāe~ 

mālā 

bahue~ 

bahu 

aurate~ 

aurat 

chiḍa◌़iyā~ 

chiḍa◌़iyā~ 

laḍa◌़kon 

laḍa◌़kon 

rāten 

rāt 

bāten 

bāt 

kakṣāe~ 

kakṣā 

vyavasthāe~ 

vyavasthā 

laḍa◌़kā 

laḍa◌़kā 



Incorrect Cases: 

laḍa◌़kon laḍa◌़kon laḍa◌़kiyon laḍa◌़kiyon The code cannot identify plurality in the oblique case. It also assumes these are singular. Eg. 

‘laḍa◌़kon' -> \('laḍa◌़kon', \['N', 'SG'\]\) Task 5: 

Regex Grouping: 

Same as Task 4 

Testing: 



Correct Cases: 

“devagaṇa" 

deva 

"chhātravarga" 

chhātra 

"laḍa◌़kiyā~" 

laḍa◌़kı̄ 

"laḍa◌़kā" 

laḍa◌़ke 

"kitāben" 

kitāb 

"mālāe~" 

mālāe~ 

"bahue~" 

bahu 

"aurat" 

aurat 

"rāte~" 

rāt 

"kakṣā" 

kakṣe 

"chiḍa◌़iyā~" 

chiḍa◌़iyā' 

"laḍa◌़kā" 

laḍa◌़ke 

"vyavasthā" 

vyavasthā 

"laḍa◌़kon" 

laḍa◌़kon 

"chiḍa◌़iyā~" 

chiḍa◌़iyā~ 



Incorrect Cases: 

laḍa◌़kon laḍa◌़kon laḍa◌़kiyon laḍa◌़kiyon The code cannot identify plurality in the oblique case.



