import re
def analyze_english(word):
    """
    Rule -based morphological analyzer for English
    """
    unchanged=["news","fish","salmon","trout","moose","sheep","deer","aircraft","species","swine","buffalo","reindeer","elk","shellfish","hovercraft","fruit","furniture","offspring","advice","gas","analysis"]
    exceptions={"wives":"wife","geese":"goose","knives":"knife","lives":"life","teeth":"tooth","mice":"mouse","feet":"foot","oxen":"ox","children":"child","brethren":"brother","cacti":"cactus","nuclei":"nucleus","fungi":"fungus","data":"datum","syllabi":"syllabus","alumni":"alumnus","criteria":"criterion","phenomena":"phenomenon","media":"medium","bacteria":"bacterium","cattle":"cow","heroes":"hero","graves":"grave"}
    pronouns={"they":"he/she","we":"I"}
    lcase=word.lower()
    if lcase in pronouns:
        return pronouns[lcase],["PN","PL"]
    if lcase in exceptions:
        return exceptions[lcase],["N","PL"]
    elif lcase in unchanged:
        return lcase,["N","SG/PL"]
    elif re.search(r"ies$",lcase):
        root = re.sub(r"ies$", "y",lcase)
        return root , ["N", "PL"]
    elif re.search(r"(xes|ches|shes|ses|zes)$",lcase):
        root = re.sub(r"es$", "",lcase)
        return root , ["N", "PL"]
    elif re.search(r"ves$",lcase):
        root=re.sub(r"ves$","f",lcase)
        return root, ["N","PL"]
    elif re.search(r"men$",lcase):
        root=re.sub(r"men$","man",lcase)
        return root, ["N","PL"]
    elif re.search(r"s$",lcase) and not re.search(r"ss$",lcase):
        root = re.sub(r"s$", "",lcase)
        return root , ["N", "PL"]
    
    # man men case ves->f case
    else:
        return lcase , ["N","SG"]

print(analyze_english("railway-men"))
print(analyze_english("stones"))
print(analyze_english("trespassers"))
print(analyze_english("calves"))
print(analyze_english("leaves"))
print(analyze_english("milk"))
print(analyze_english("water"))
print(analyze_english("half"))
print(analyze_english("catches"))
print(analyze_english("they"))
print(analyze_english("movies"))
print(analyze_english("data"))
print(analyze_english("alumni"))
print(analyze_english("news"))
print(analyze_english("specimen"))
#leaves leave leaf case


